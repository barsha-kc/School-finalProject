let menuData = []; // Store fetched data globally for sorting

let pageType = "other";
if (document.querySelector(".menu-container")) {
  pageType = "menu";
} else if (document.querySelector(".cart-container")) {
  pageType = "cart";
}

// Fetch data and render menu
async function fetchData() {
  const response = await fetch(
    "https://6762d1f417ec5852cae7350f.mockapi.io/food"
  );
  menuData = await response.json();

  if (pageType === "menu") {
    renderMenu(menuData);
  }
}

// Render menu items
function renderMenu(data) {
  const menuContainer = document.querySelector(".menu-container");
  menuContainer.innerHTML = "";

  data.forEach((item) => {
    const menuItem = document.createElement("div");
    menuItem.classList.add("menu-item");

    menuItem.innerHTML = `
      <h2>${item.name}</h2>
      <img src="${item.image}?lock=${item.id}" alt="${item.name}">
      <span>€${item.price}</span>
      <button class="add-to-cart" onclick="addToCart(${item.id})">Add to cart</button>
    `;
    menuContainer.appendChild(menuItem);
  });
}

// Render cart items
function renderCart() {
  const cart = JSON.parse(localStorage.getItem("cart")) || [];

  const cartContainer = document.querySelector(".cart-container");
  cartContainer.innerHTML = "";

  cart.forEach((item) => {
    const cartItem = document.createElement("div");
    cartItem.classList.add("cart-item");

    cartItem.innerHTML = `
      <h2>${item.name}</h2>
      <img src="${item.image}?lock=${item.id}" alt="${item.name}">
      <span>€${item.price}</span>
      <span>Quantity: ${item.count}</span>
      <button class="remove-from-cart" onclick="removeFromCart(${item.id})">Remove</button>
    `;
    cartContainer.appendChild(cartItem);
  });
}

// Add item to cart
function addToCart(itemId) {
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  const itemDetails = menuData.find(
    (item) => Number.parseInt(item.id) === itemId
  );

  const existingItem = cart.find((item) => Number.parseInt(item.id) === itemId);

  if (existingItem) {
    existingItem.count++;
  } else {
    cart.push({ ...itemDetails, count: 1 });
  }

  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCounter();
}

// Remove item from cart
function removeFromCart(itemId) {
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  const newCart = cart.filter((item) => Number.parseInt(item.id) !== itemId);

  localStorage.setItem("cart", JSON.stringify(newCart));
  renderCart();
  updateCartCounter();
}

// Update cart counter
function updateCartCounter() {
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  const cartCount = document.querySelector(".cart-count");
  cartCount.textContent = cart.length;
  cartCount.style.display = cart.length ? "block" : "none";
}

// Sort menu items
function sortMenu(option) {
  let sortedData = [...menuData];
  switch (option) {
    case "initials-asc":
      sortedData.sort((a, b) => a.name.localeCompare(b.name));
      break;
    case "initials-desc":
      sortedData.sort((a, b) => b.name.localeCompare(a.name));
      break;
    case "price-asc":
      sortedData.sort((a, b) => a.price - b.price);
      break;
    case "price-desc":
      sortedData.sort((a, b) => b.price - a.price);
      break;
  }
  renderMenu(sortedData);
}

// Setup event listeners
function setupEventListeners() {
  document.querySelector("#sort-options").addEventListener("change", (e) => sortMenu(e.target.value));
  document.querySelector("#search-button").addEventListener("click", handleSearch);
}

function handleSearch() {
  const searchInput = document.querySelector("#search-input").value.toLowerCase();
  const filteredData = menuData.filter((item) => item.name.toLowerCase().includes(searchInput));
  renderMenu(filteredData);
}

// Initialize the page
fetchData();
updateCartCounter();

if (pageType === "menu") {
  setupEventListeners();
}

if (pageType === "cart") {
  renderCart();
}